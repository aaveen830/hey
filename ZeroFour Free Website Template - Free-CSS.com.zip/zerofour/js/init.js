_5grid.ready(function() {

	if (_5grid.isDesktop)
	{
		$('#nav > ul').dropotron({ 
			offsetY: -22,
			mode: 'fade',
			noOpenerFade: true
		});
	}

});